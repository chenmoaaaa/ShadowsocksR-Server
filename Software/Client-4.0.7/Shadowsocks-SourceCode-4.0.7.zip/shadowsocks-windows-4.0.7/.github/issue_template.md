Please read Wiki carefully, especially https://github.com/shadowsocks/shadowsocks-windows/wiki/Troubleshooting.
Please answer these questions before submitting your issue. Thanks!

### Version(release version or AppVeyor link)


### Environment(Operating system, .NET Framework, etc)


### Steps you have tried


### What did you expect to see?


### What did you see instead?


### Config and error log in detail (with all sensitive info masked)